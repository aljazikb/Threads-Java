/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_4_cpit425;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aljaz
 */
public class Thread2 extends Thread{
    
    String file="";
    
    public Thread2 (String fileName){
       file= fileName;
    }
    @Override
    public void run(){
        
        for(int i=0;i<3 ;i++){
            try(BufferedReader br = new BufferedReader(new FileReader(file))){
            System.out.println( br.readLine());
             Thread.sleep(1000);
           
       } catch (IOException ex) {
            Logger.getLogger(ThreadOne.class.getName()).log(Level.SEVERE, null, ex); } catch (InterruptedException ex) {
                Logger.getLogger(Thread2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }  
}
    

