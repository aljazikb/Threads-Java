/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_4_cpit425;

/**
 *
 * @author aljaz
 */
public class Lab_4_CPIT425 {

   
    public static void main(String[] args) throws InterruptedException {
        
        ThreadOne write=new ThreadOne("aljazi.txt");
        Thread2 read=new Thread2("aljazi.txt");
        //System.out.println(one.isAlive());
        
        //System.out.println(one.getName());
        //one.setName("First thread");
         //System.out.println(one.getName());
         //System.out.println(one.getPriority());
         //System.out.println(one.activeCount());
        
        
         write.start(); 
         System.out.println("Is thread One alive?"+write.isAlive());
         write.setName("WRITE");
         System.out.println("Thread "+write.getName()+" has start");
         write.join();
         System.out.println("Is thread One alive?"+write.isAlive());
         
         System.out.println("-----------------------------------");
         
         
        read.start();
        System.out.println("Is thread Two alive?"+read.isAlive());
        read.setName("READ");
        System.out.println("Thread "+read.getName()+" has start");
        
        System.out.println("Is thread Two alive?"+read.isAlive());

        
    }
    
}
