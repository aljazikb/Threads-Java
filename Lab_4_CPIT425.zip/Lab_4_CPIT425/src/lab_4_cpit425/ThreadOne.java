package lab_4_cpit425;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aljaz
 */
public class ThreadOne extends Thread{
    
    String file="";
    
    public ThreadOne (String fileName){
       file= fileName;
    }
    
    @Override
    public void run(){
        
       try(BufferedWriter bw = new BufferedWriter(new FileWriter(this.file))){
           bw.write("Welcome to The Thread Lab. Aljazi Banaemah");
           System.out.println("the print in file is done");
       } catch (IOException ex) {
            Logger.getLogger(ThreadOne.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
